# AGENTS.md — Universal Project Rules

## Stack
- Next.js 15 App Router, TypeScript STRICT, Tailwind, shadcn/ui
- Prisma + PostgreSQL, Redis (Upstash)
- React Hook Form + Zod
- NextAuth.js v5 / Clerk
- Deploy: Vercel

## The Four Elements (Every Prompt Must Have)
1. **Goal:** Outcome, not method.
2. **Context:** Files, folders, docs, errors (@ mentions).
3. **Constraints:** Standards, architecture, safety.
4. **Done when:** Verifiable condition (tests pass, behavior verified).

## Universal Rules
1. Read 3 similar files before writing new code.
2. NEVER use `any`. NEVER raw SQL. NEVER commit secrets.
3. Server Component default. Client Component only for interactivity.
4. All API routes: Zod validation → typed response → error handling → rate limiting.
5. All DB queries: select specific fields, use indexes, transactions for multi-write.
6. Run `typecheck && lint && test` after every change.
7. Plan → Implement → Review. No code without approved plan for non-trivial changes.
8. Simplicity first. Complex patterns need explicit justification.
9. Security by default. Validate all inputs. Defense in depth. Least privilege.
10. Self-documenting code. Comments explain WHY, not WHAT. Meaningful names only.
11. One task per thread. Fork session if context degrades.
12. Positive framing only. "Use real data" > "Don't use mock data".

## Progressive Disclosure
- DB work → `.ai/rules/database.md`
- API work → `.ai/rules/api-design.md`
- Auth/Security → `.ai/rules/security.md`
- UI/UX → `.ai/rules/frontend.md`
- Testing → `.ai/rules/testing.md`
- Architecture → `.ai/rules/architecture.md`

## Off-Limits
- `.env*`, `docker-compose.yml`, payment secrets, auth keys
- New dependencies without justification
- DB schema changes without migration + rollback
- CI/CD configs unless explicitly asked
- Comments explaining what code does
- TODO/FIXME without ticket reference

## Workflow
1. **PLAN:** Propose approach, files, risks. Wait approval. Use Plan Mode for complex tasks.
2. **IMPLEMENT:** Code per plan only. No scope creep.
3. **REVIEW:** Run verification. Summarize changes & risks. Confirm no regression.
