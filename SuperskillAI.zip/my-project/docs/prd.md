# PRD — [Feature Name]

## 1. Overview
- **Goal:** One sentence describing the outcome
- **Success Metrics:** Measurable criteria (conversion, load time, error rate)
- **Stakeholders:** Product owner, tech lead, designer

## 2. User Stories
```
As a [user type], I want [action], so that [benefit]
```
- US-1: As a user, I want to reset password via email, so I can regain access
- US-2: As an admin, I want to filter orders by status, so I can process efficiently

## 3. Functional Requirements
- FR-1: System sends reset email within 30 seconds
- FR-2: Reset link expires after 1 hour
- FR-3: Admin sees orders paginated (50/page) with status filter

## 4. Non-Functional Requirements
- **Performance:** API response <200ms p95
- **Security:** Reset token cryptographically random, single-use
- **Accessibility:** All forms keyboard navigable, screen reader friendly
- **Browser:** Last 2 versions of Chrome, Firefox, Safari, Edge
- **Reliability:** 99.9% uptime during business hours

## 5. UI/UX Requirements
- **Design:** Figma link [URL]
- **Responsive:** Mobile-first, breakpoints per frontend.md
- **States:** Loading, Empty, Error, Success
- **Animations:** Subtle fade (200ms) for modals

## 6. API Requirements
- **Endpoints:** `POST /api/auth/reset-password`, `GET /api/orders`
- **Validation:** Zod schemas (link to validation file)
- **Rate Limit:** 5 req/min per IP for reset, 100 req/min for orders
- **Auth:** Public (reset), Admin role (orders)

## 7. Data Requirements
- **Schema Changes:** Add `passwordResetToken`, `passwordResetExpires` to User model
- **Migration:** Backward compatible (nullable first)
- **Indexing:** Index on `passwordResetToken` (unique, sparse)

## 8. Testing Requirements
- **Unit:** Token generation, email template rendering
- **Integration:** API route validation, DB state after reset
- **E2E:** Full flow: request reset → click email → set password → login
- **Edge Cases:** Expired token, reused token, invalid email

## 9. Rollout Plan
- **Phase 1:** Feature flag (10% users)
- **Phase 2:** Monitor error rate for 48 hours
- **Phase 3:** 100% rollout
- **Rollback:** Disable feature flag instantly

## 10. Open Questions
- [ ] Which email provider? (SendGrid vs AWS SES)
- [ ] CAPTCHA on reset form?
- [ ] Notify user on password change?
