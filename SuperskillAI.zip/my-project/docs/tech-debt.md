# tech-debt.md — Technical Debt Log

> Review weekly. Prioritize by impact.

## Format
```markdown
### [YYYY-MM-DD] Title
- **Location:** `file/path.ts`
- **Context:** Why it was done this way
- **Impact:** Performance, security, maintainability, DX
- **Effort:** Small / Medium / Large
- **Priority:** P0 (fix now) / P1 (next sprint) / P2 (backlog)
- **Owner:** @name
- **Ticket:** LINK-123
```

## Example

### 2026-06-20 Missing DB Index on Order Status
- **Location:** `prisma/schema.prisma` — Order model
- **Context:** Added status but forgot index during fast implementation
- **Impact:** Query timeout on admin dashboard with 100k+ orders
- **Effort:** Small
- **Priority:** P1
- **Owner:** AI
- **Ticket:** WEB-204

## Rules
- Every shortcut or "temporary" fix MUST be logged within 24 hours
- AI MUST check this file before starting new tasks
- Review weekly during architecture review
- Close items when resolved with PR link
