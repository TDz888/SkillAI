# CLAUDE.md — Claude Code Reference

> See AGENTS.md for universal rules.

## Quick Context
- **Build:** `npm run build` (typecheck + lint must pass)
- **Dev:** `npm run dev` (Turbopack)
- **Test:** `npm run test` (Vitest), `npm run test:e2e` (Playwright)
- **DB:** `npx prisma migrate dev` (local), `npx prisma migrate deploy` (prod)
- **Lint:** `npm run lint` (ESLint + Prettier)

## Folder Structure
```
app/              → App Router (Server Components default)
components/ui/    → shadcn/ui (copy, don't install)
lib/
  actions/      → Server Actions
  services/     → Business logic (pure, testable)
  repositories/ → Data access (Prisma only)
  validations/  → Zod schemas (shared FE/BE)
  utils/        → Pure utilities (no side effects)
types/            → Global types
prisma/           → Schema + migrations
public/           → Static assets
```

## Conventions
- Files: kebab-case. Components: PascalCase. Types: PascalCase.
- API routes: `route.ts` in resource folder (`app/api/users/route.ts`)
- Server Actions: `actions.ts` in feature folder
- Zod schemas: `[Feature]Schema`
- Services: `[Feature]Service` — pure functions, no framework deps
- Repositories: `[Feature]Repository` — Prisma only, no business logic

## Skills
- `.claude/skills/write-tests/SKILL.md`
- `.claude/skills/review-code/SKILL.md`
- `.claude/skills/refactor-safe/SKILL.md`
