# failures.md — Known Failures & Prevention

## 1. AI Used `any` to "Fix" Type Error
- **Symptom:** `const data: any = await response.json()`
- **Impact:** Lost type safety, propagated errors
- **Prevention:** NEVER `any`. Use `unknown` + Zod parse.
- **Detection:** ESLint `@typescript-eslint/no-explicit-any`

## 2. AI Forgot Rate Limiting
- **Symptom:** Public API without rate limit
- **Impact:** DDoS vulnerable, cost spike
- **Prevention:** api-design.md mandates rate limit. Review catches.
- **Detection:** Security audit checklist

## 3. AI Created N+1 Query
- **Symptom:** `users.map(u => prisma.post.findMany(...))`
- **Impact:** 100 users = 101 queries. DB timeout.
- **Prevention:** Repository review. Use `include` or bulk query.
- **Detection:** Prisma logging + query count alert

## 4. AI Stored Secret in Code
- **Symptom:** `const API_KEY = "sk-live-..."` in component
- **Impact:** Secret leaked to client, Git history
- **Prevention:** `.env` only. ESLint `no-hardcoded-secrets`. Pre-commit hook.
- **Detection:** GitLeaks or TruffleHog

## 5. AI Broke Responsive Design
- **Symptom:** Fixed widths, no mobile classes
- **Impact:** 60% users on mobile have bad experience
- **Prevention:** frontend.md mandates mobile-first. Review checks.
- **Detection:** Playwright mobile viewport test

## 6. AI Added Unnecessary Dependency
- **Symptom:** Added `lodash` for one `debounce`
- **Impact:** Bundle bloat, supply chain risk
- **Prevention:** AGENTS.md forbids new deps without approval. Use built-in.
- **Detection:** Bundle analyzer + dependency audit

## 7. AI Wrote Client Component for Static Display
- **Symptom:** `'use client'` on static card
- **Impact:** Unnecessary JS bundle
- **Prevention:** frontend.md: Server Component default.
- **Detection:** Code review + Lighthouse

## 8. AI Forgot Error Handling in Async
- **Symptom:** `await fetchData()` without try/catch
- **Impact:** Unhandled rejection, crash
- **Prevention:** error-handling.md mandates catch at boundaries.
- **Detection:** ESLint `require-atomic-updates`, runtime tracking

## 9. AI Used Magic Numbers
- **Symptom:** `if (status === 3)` instead of enum
- **Impact:** Unreadable, bugs when values change
- **Prevention:** standards.md mandates named constants.
- **Detection:** ESLint `no-magic-numbers`

## 10. AI Mixed Multiple Tasks in One Session
- **Symptom:** Context pollution, contradictory instructions
- **Impact:** Rework, bugs, wasted tokens
- **Prevention:** AGENTS.md: One task per thread. Fork session.
- **Detection:** Session quality metrics
