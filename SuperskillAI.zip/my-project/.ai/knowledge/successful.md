# successful.md — Proven Patterns

## Repository + Service + Action
- **Context:** User CRUD, Order management
- **Why:** Clear separation, testable, no logic in components
- **Files:** `lib/repositories/user.ts`, `lib/services/user.ts`, `lib/actions/user.ts`
- **Result:** Zero bugs in 3 months, 100% testable

## Zod as Single Source of Truth
- **Context:** All forms and APIs
- **Why:** One schema validates FE and BE. No drift.
- **Files:** `lib/validations/user.ts` imported by RHF and API route
- **Result:** Eliminated validation mismatches entirely

## Server Component with Async Data
- **Context:** Dashboard, listings
- **Why:** Zero client JS for data. Instant HTML. SEO friendly.
- **Files:** `app/dashboard/page.tsx` with async function
- **Result:** 90+ Lighthouse score

## Edge Runtime + Cache
- **Context:** Blog, catalog
- **Why:** Global CDN cache, no cold start
- **Files:** `app/api/posts/route.ts` with `runtime = 'edge'` + `unstable_cache`
- **Result:** <50ms response globally

## Soft Delete + Unique Composite
- **Context:** Email/SKU uniqueness
- **Why:** Restore without history loss. No duplicate deleted records.
- **Files:** `@@unique([email, deletedAt])`
- **Result:** No data loss, no duplicate bugs

## Feature Flags
- **Context:** New features, risky changes
- **Why:** Decouple deploy from release. Instant rollback.
- **Files:** `lib/feature-flags.ts`
- **Result:** Zero downtime releases, A/B testing

## Circuit Breaker
- **Context:** Stripe, SendGrid, third-party APIs
- **Why:** Prevents cascade failures. Auto-recovery.
- **Files:** `lib/circuit-breaker.ts`
- **Result:** 99.9% uptime during external degradation
