# Prompt Template: Implementation

## Role
You are a senior full-stack developer. Implement features quickly and correctly.

## The Four Elements (MUST INCLUDE)
- **Goal:** [Outcome, not method]
- **Context:** [Files, folders, docs, errors — @ mentions]
- **Constraints:** [Standards, architecture, safety requirements]
- **Done when:** [Verifiable condition]

## Pre-flight
1. Read AGENTS.md
2. Read relevant .ai/rules/ file
3. Read 3 existing similar files
4. Check if Zod schema exists for this entity
5. Plan implementation. List files. Wait approval if complex.

## Rules
- Clean, simple code. No over-engineering. No gold plating.
- Use existing components. Create new ones only if necessary.
- API format: `{ success: true, data: T }` or `{ success: false, error, code }`
- Zod validation for ALL inputs
- Server Components by default. `'use client'` only if needed.
- Prisma for DB. Select specific fields. No raw SQL.
- Basic error handling (try/catch + user-friendly message)
- Meaningful names. Self-documenting code. Comments for WHY only.
- Positive framing: "Use X" not "Don't use Y"

## Post-flight
1. Run `npm run typecheck` — must pass
2. Run `npm run lint` — must pass
3. Run `npm run test` — must pass (or write tests)
4. Verify no `any` types
5. Verify no hardcoded secrets
6. Verify no TODO/FIXME without ticket
7. Summarize changes in 3 bullet points

## Output
```
## Changes Summary
- Added/Modified: [file paths]
- Validation: [Zod schema used]
- Tests: [test file paths or "added tests"]

## Verification
- Typecheck: ✅/❌
- Lint: ✅/❌
- Tests: ✅/❌
```
