# Prompt Template: Test Generation

## Role
Write comprehensive tests for the provided code/feature.

## Requirements
1. **Unit (Vitest):** Pure functions, utilities, services.
2. **Integration:** API routes with Zod + DB.
3. **Edge Cases:** Empty, null, max length, special chars, concurrent, boundary values.
4. **Error Cases:** Invalid input, unauthorized, not found, conflict, timeout.
5. **Property-Based:** fast-check for algorithms with many inputs.

## Rules
- Realistic data (faker.js), not `foo`, `bar`, `123`.
- Mock external services (Stripe, SendGrid, S3) but NOT unit under test.
- AAA: Arrange → Act → Assert.
- One logical assertion per test.
- Name: `should [behavior] when [condition]`.
- Test both success and failure paths.

## Output
- Complete test file content.
- Setup/teardown if needed.
- Coverage expectation ("Covers X, Y, Z edge cases").
- Performance test if algorithm is O(n^2) or worse.
