# database.md — Database Rules

## Schema Design
- IDs: `cuid()` or `uuid()`. NEVER auto-increment for public IDs.
- Timestamps: `createdAt` + `updatedAt` on every model. `@updatedAt`.
- Soft delete: `deletedAt DateTime?` + `@@index([deletedAt])`. Filter `deletedAt: null` by default.
- Enums: Prisma enum for fixed values.
- Relations: Both sides defined. `onDelete: Cascade` or `Restrict` explicit.
- Normalization: 3NF default. Denormalize ONLY for proven read-heavy needs.

## Indexing (Mandatory)
- Index ALL fields in `where`, `orderBy`, joins.
- Composite: `@@index([userId, status])`.
- Unique: `@@unique([email, deletedAt])` for soft-delete unique.
- Covering indexes for frequently read columns.

## Query Rules
- Select specific fields. BAD `findMany()`, GOOD `findMany({ select: {...} })`.
- No N+1. Use `include` carefully. Prefer separate queries + manual join if complex.
- Transactions: `prisma.$transaction([...])` for multi-write. Interactive for conditional logic.
- Pagination: Always. Cursor-based for infinite scroll, offset for admin tables.
- Raw SQL: FORBIDDEN except complex reports (read-only, parameterized, senior review).
- Connection pooling: PgBouncer in production. Set `connection_limit`.

## Migration Rules
- Every change = migration file.
- Name: descriptive, e.g., `add_user_soft_delete`.
- Backward-compatible: add nullable → deploy → populate → make required.
- NEVER drop column/table in same migration removing code dependency.
- Rollback plan required for destructive migrations.
- Test on staging before production.

## Soft Delete Middleware Pattern
```ts
// prisma/middleware/soft-delete.ts
prisma.$use(async (params, next) => {
  if (params.action === 'findUnique' || params.action === 'findFirst') {
    params.args.where = { ...params.args.where, deletedAt: null };
  }
  if (params.action === 'findMany') {
    params.args.where = { ...params.args.where, deletedAt: null };
  }
  return next(params);
});
```
- For admin queries needing deleted records, bypass middleware explicitly.
- Audit log all deletes. Scheduled job for permanent purge after retention period.

## Repository Template
```ts
import { prisma } from "@/lib/db";
import { Prisma } from "@prisma/client";

export class UserRepository {
  static async findById(id: string) {
    return prisma.user.findUnique({
      where: { id, deletedAt: null },
      select: { id: true, email: true, name: true, createdAt: true },
    });
  }

  static async create(data: Prisma.UserCreateInput) {
    return prisma.user.create({ data, select: { id: true, email: true } });
  }

  static async softDelete(id: string) {
    return prisma.user.update({ where: { id }, data: { deletedAt: new Date() } });
  }
}
```
