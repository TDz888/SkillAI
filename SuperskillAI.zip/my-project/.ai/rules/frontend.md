# frontend.md — Frontend Rules

## Component Architecture
- Server Component default. `'use client'` ONLY for:
  - Event handlers (`onClick`, `onSubmit`)
  - Hooks: `useState`, `useEffect`, `useContext`, `useRef`
  - Browser APIs
  - Third-party widgets
- Data fetching: Server Components use async/await. Client Components use TanStack Query.
- Forms: React Hook Form + Zod resolver. NEVER uncontrolled without validation.

## UI/UX Standards
- Responsive: Mobile-first (sm → md → lg → xl). Test 320px, 768px, 1440px.
- Accessibility: WCAG 2.1 AA. All images have alt. All inputs have labels. Focus visible. Keyboard navigable. axe-core automated testing.
- Dark mode: `dark:` classes. Respect `prefers-color-scheme`. shadcn native support.
- Loading: Skeleton screens. No layout shift.
- Error: Error boundaries (`error.tsx`). Toast for action feedback.
- Empty: Never blank. Helpful empty state with CTA.
- Performance Budget: FCP <1.8s, LCP <2.5s, TBT <200ms.

## Styling
- Tailwind only. No inline styles. No CSS-in-JS.
- Custom classes in `globals.css` for `@layer base` or complex animations.
- `cn()` utility (clsx + tailwind-merge) for conditional classes.
- Color tokens: CSS variables. No hardcoded hex.
- Spacing: Tailwind scale. No arbitrary values unless necessary.

## shadcn/ui
- Install: `npx shadcn add [component]`
- Customize in `components/ui/` only. Don't modify node_modules.
- Composition: Combine primitives (Dialog + Form + Table).
- Don't over-componentize. Used once = no extraction.

## Performance
- `next/image` for ALL images. Specify width/height. Prevent CLS.
- Lazy load below-fold: `dynamic(() => import('./Heavy'))`
- `React.memo` sparingly. Profile first.
- Avoid `useEffect` for derived state. Compute in render.
- Prevent prop drilling: Server Component composition or Context.
- Core Web Vitals: Monitor LCP, FID, CLS, TTFB, INP.
