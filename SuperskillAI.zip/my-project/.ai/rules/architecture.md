# architecture.md — System Architecture

## Philosophy
- Monorepo-lite: Single repo for FE + BE. One source of truth.
- Type Safety: TypeScript STRICT. Zero `any`.
- Edge-First: Public APIs on Edge Runtime when possible.
- Server-First: Server Components default. Client Components only for browser APIs, real-time interactivity, third-party widgets.

## Layered Architecture
```
Presentation (Server → Client Components)
  ↓
Server Actions / API Routes (Controllers)
  ↓
Services (Business Logic — pure, testable, framework-agnostic)
  ↓
Repositories (Data Access — Prisma only)
  ↓
Database (PostgreSQL + Redis)
```

## SOLID for AI
- **S:** One reason to change per module.
- **O:** Extend via composition, not modification.
- **L:** Subtypes substitutable. No breaking interfaces.
- **I:** Small, focused interfaces. No god-objects.
- **D:** Depend on abstractions. Inject dependencies.

## Rules
- No business logic in components. Move to `lib/services/`.
- No Prisma calls in components. Only in Actions or API routes.
- Repository Pattern: All DB access through `lib/repositories/[feature].ts`.
- Dependency direction: UI → Actions → Services → Repositories → DB.
- No circular dependencies. Enforced by ESLint.
- Domain-Driven: Group by feature, not layer. `features/user/`, `features/order/`.
- CQRS Lite: Separate read/write models when query complexity differs.

## File Organization
```
app/
  (dashboard)/     → Route groups
  api/             → REST routes
  auth/            → Auth routes
features/
  user/
    actions.ts     → Server Actions
    service.ts     → Business logic
    repository.ts  → Data access
    validations.ts → Zod schemas
    types.ts       → Feature types
lib/
  actions/         → Cross-cutting actions
  services/        → Cross-cutting services
  repositories/    → Cross-cutting repositories
  validations/     → Shared schemas
  utils/           → Pure utilities
types/             → Global types
```

## Performance
- `React.cache()` for deduplicated data fetching.
- `unstable_cache` for route-level caching.
- `Suspense` + streaming for slow data.
- `<Image>` with priority/lazy, WebP format.
- `next/font` for font optimization.
- Dynamic imports for heavy components.
