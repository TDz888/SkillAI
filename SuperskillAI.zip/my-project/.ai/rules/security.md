# security.md — Security Rules

## Auth & Authorization
- Use NextAuth.js v5 or Clerk. NEVER roll your own auth.
- Passwords: bcrypt 12+ rounds. Prefer OAuth/SAML.
- JWT: 15-min access, 7-day httpOnly refresh.
- Session: Server-side in Redis/DB. No sensitive data in client cookie.
- RBAC: Role checks in Actions AND API routes. Trust no one.
- Middleware: Next.js middleware for route protection. NOT client-side only.
- Zero Trust: Verify every request. Assume breach.

## Input Security
- Validate ALL inputs with Zod (type + format + length + sanitize).
- Sanitize HTML: DOMPurify for user content.
- File uploads: Validate MIME, size limit, scan with ClamAV. Store outside web root.
- SQL injection: Prisma ORM only. No raw SQL.
- XSS: Escape output. CSP headers.
- CSRF: NextAuth/Clerk handles. Custom forms verify origin.
- SSRF: Validate URLs before fetching. No internal IP access.

## Headers & CSP
```
Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-eval' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' blob: data:; font-src 'self'; connect-src 'self' https://api.example.com; frame-ancestors 'none'; base-uri 'self'; form-action 'self';
X-Frame-Options: DENY
X-Content-Type-Options: nosniff
Referrer-Policy: strict-origin-when-cross-origin
Permissions-Policy: camera=(), microphone=(), geolocation=()
Strict-Transport-Security: max-age=63072000; includeSubDomains; preload
```

## Secrets
- ALL secrets in `.env.local` / Vercel Environment.
- NEVER commit `.env`. Check `.gitignore`.
- Rotate quarterly. Use 1Password/Vault.
- External API keys: Encrypt in DB if multi-tenant.

## Dependencies
- `npm audit` weekly. Fix high/critical within 24h.
- Dependabot/Snyk alerts.
- Pin versions. Review lockfile changes.
- No unused deps. Remove promptly.
- Check malicious packages before adding (snyk advisor, socket.dev).

## AI-Specific Security
- Review AI code for zero-width joiners, bidirectional markers, hidden unicode.
- Review AI rules for backdoor instructions.
- NEVER let AI modify `.env`, CI/CD, auth configs without human review.
- SAST (Semgrep/CodeQL) on every AI-generated PR.
- Maintain audit trail of all AI changes.

## R.A.I.L.G.U.A.R.D
- Request validation, Auth/Authz, Input sanitization
- Least privilege, Guardrails, Unified logging
- Audit trails, Rate limiting, Defense in depth
