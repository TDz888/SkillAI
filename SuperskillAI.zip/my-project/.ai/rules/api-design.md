# api-design.md — API Design

## REST Conventions
- Resource URLs: `/api/users`, `/api/users/:id/posts`
- Verbs: GET (read), POST (create), PUT/PATCH (update), DELETE (remove)
- No verbs in URLs: BAD `/api/createUser`, GOOD `POST /api/users`

## Request/Response
- Request: Always Zod validated. Reject 400 + details.
- Response envelope:
  ```ts
  type ApiResponse<T> = 
    | { success: true; data: T; meta?: PaginationMeta }
    | { success: false; error: string; code: string; details?: unknown };
  ```
- Status: 200 OK, 201 Created, 400 Bad Request, 401 Unauthorized, 403 Forbidden, 404 Not Found, 409 Conflict, 422 Validation Error, 429 Too Many Requests, 500 Internal Error

## Validation
- Zod for EVERY input: body, query, params, headers.
- Coerce: `z.coerce.number()`, `z.coerce.date()`
- Custom error messages in consistent language.
- Never trust client input.

## Rate Limiting
- Public: 100 req/min per IP (Redis).
- Authenticated: 1000 req/min per userId.
- Burst: 10 req/s.
- Return `Retry-After` on 429.

## Error Handling
- Catch ALL errors. No stack traces to client.
- Log full error server-side (correlation-id + timestamp).
- User-friendly message + error code.
- RFC 7807 Problem Details for complex APIs.

## Versioning
- URL: `/api/v1/users` (preferred external).
- Header: `Accept: application/vnd.api.v1+json` (internal flexibility).
- Never break existing contracts. Deprecate with sunset headers.

## Template
```ts
import { z } from "zod";
import { rateLimit } from "@/lib/rate-limit";

const schema = z.object({
  email: z.string().email(),
  name: z.string().min(2),
});

export async function POST(req: Request) {
  try {
    await rateLimit(req);
    const body = await req.json();
    const data = schema.parse(body);
    const result = await createUser(data);
    return Response.json({ success: true, data: result }, { status: 201 });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return Response.json({ success: false, error: "Invalid input", code: "VALIDATION_ERROR", details: error.flatten() }, { status: 400 });
    }
    console.error("[API Error]", error);
    return Response.json({ success: false, error: "Internal server error", code: "INTERNAL_ERROR" }, { status: 500 });
  }
}
```
