# testing.md — Testing Rules

## Pyramid
```
E2E (Playwright)     → 5%  Critical journeys
Integration          → 15% Route + DB + Service
Unit (Vitest)        → 80% Pure functions, utilities, services
```

## Unit (Vitest)
- Test pure functions, business logic, utilities.
- Mock external deps (DB, API, filesystem).
- Naming: `[function].test.ts` next to source.
- Coverage: >90% services, >80% utilities, >70% overall.
- AAA: Arrange → Act → Assert.
- One assertion per test. Max 3 if related.
- Property-based: fast-check for complex algorithms.

## Integration
- Test API routes with test DB (Docker PostgreSQL).
- Happy path + common errors.
- Reset DB between tests (`beforeEach`).
- Factory pattern for test data (faker.js).
- Contract testing: Validate API contracts against consumers.

## E2E (Playwright)
- Critical flows: login → dashboard → create → logout.
- Run against local build (`build && start`).
- Parallel execution. Isolate tests.
- Screenshots on failure. Video for CI.
- Accessibility: axe-core integration.

## AI Rules
- AI MUST write tests BEFORE or WITH implementation.
- AI MUST run tests and fix failures before done.
- AI MUST NOT mock unit under test.
- AI MUST use realistic data, not `foo`, `bar`, `123`.
- AI MUST cover edge cases: empty, null, max length, special chars, concurrent.
- AI MUST test error paths.

## Template
```ts
import { describe, it, expect } from "vitest";
import { calculateTotal } from "./cart.service";

describe("calculateTotal", () => {
  it("should sum items and apply discount", () => {
    const items = [{ price: 100, qty: 2 }, { price: 50, qty: 1 }];
    const result = calculateTotal(items, 0.1);
    expect(result).toBe(225);
  });

  it("should throw on negative discount", () => {
    expect(() => calculateTotal([], -0.1)).toThrow("Invalid discount");
  });

  it("should handle empty cart", () => {
    expect(calculateTotal([], 0)).toBe(0);
  });
});
```
