---
name: refactor-safe
description: >
  Safely refactor code without changing behavior. Improves readability and maintainability.
  Activates when user mentions "refactor", "clean up", "simplify", or "đẹp hơn".
---

# Refactor Safe Skill

## When to Use
- Code works but is messy
- User wants to improve readability
- Removing technical debt
- Preparing code for review

## Constraints (Hard Rules)
- BEHAVIOR MUST NOT CHANGE. Output identical.
- All existing tests pass without modification.
- No new dependencies.
- No logic changes (structure, naming, formatting only).

## Allowed
- Extract function / variable / constant
- Rename for clarity
- Flatten nested conditionals (early returns)
- Remove dead code
- Convert to modern syntax (optional chaining, nullish coalescing)
- Add JSDoc (only if missing)
- Reorder functions for readability
- Replace magic numbers with named constants

## Forbidden
- Change algorithm or logic flow
- Modify API signatures (without migration)
- Change data structures
- Add/remove features
- Optimize performance (measure first)

## Workflow
1. Read target file(s)
2. Identify smell: long function, deep nesting, magic numbers, duplicate code
3. Plan refactor steps (list them)
4. Execute one step at a time
5. Run tests after each step
6. Final verification: `typecheck && lint && test`

## Output
```
## Refactor Summary
- File: [path]
- Smells fixed: [list]
- Changes: [bullet points]
- Tests: ✅ All pass (no changes needed)
- Behavior: ✅ Verified identical
```
