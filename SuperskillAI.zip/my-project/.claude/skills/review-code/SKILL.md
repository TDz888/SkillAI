---
name: review-code
description: >
  Production-ready code review. Catches security, performance, architectural issues.
  Activates when user mentions "review", "review code", "check lỗi", or "production ready".
---

# Review Code Skill

## When to Use
- Before merging any non-trivial change
- When user asks for code review
- After AI implements a feature (self-review)
- When debugging production issues

## Workflow
1. Read all files changed
2. Read 3 similar existing files for pattern consistency
3. Check against .ai/rules/ (security, api-design, database, frontend, testing)
4. Identify issues by severity (Critical / High / Medium / Low)
5. Suggest specific fixes with code examples
6. DO NOT modify code unless explicitly asked (advisory mode)

## Dimensions
- **Correctness:** Does it do what it claims? Logic bugs?
- **Type Safety:** Any `any`? Proper Zod?
- **Security:** Input validation, auth, secrets, injection, SSRF
- **Performance:** N+1, missing indexes, unnecessary renders, bundle size
- **Maintainability:** Readability, naming, DRY, SOLID
- **Testing:** Coverage, realistic mocks, edge cases
- **Observability:** Logging, error handling, monitoring

## Output
```markdown
## Code Review: [Feature/File]

### 🔴 Critical (Block)
1. [Issue + file + line + fix]

### 🟡 High (Fix before merge)
1. [Issue + suggestion]

### 🟢 Medium (If time)
1. [Issue + suggestion]

### ✅ Positive
- [What was done well]

### Next Steps
1. [Action items]
```
