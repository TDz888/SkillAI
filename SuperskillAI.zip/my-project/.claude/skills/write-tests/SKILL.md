---
name: write-tests
description: >
  Write comprehensive unit and integration tests.
  Activates when user mentions "test", "viết test", "coverage", or asks to verify code.
---

# Write Tests Skill

## When to Use
- User asks to write tests
- User asks to verify code correctness
- After implementing a feature (mandatory follow-up)
- During review when coverage is missing

## Workflow
1. Identify code to test (file path or feature)
2. Read source code and understand inputs/outputs
3. Check .ai/rules/testing.md for standards
4. Write tests following AAA pattern
5. Run tests and fix until passing
6. Report coverage summary

## Rules
- Use Vitest for unit, Playwright for E2E
- Mock external dependencies (DB, API, filesystem)
- Use realistic data patterns, not `foo`/`bar`
- Cover happy path + 3 edge cases minimum
- Never test implementation details (behavior, not internals)
- Add property-based tests for complex algorithms

## Output
```
## Test Plan for [Feature]
- Unit tests: [functions to test]
- Integration tests: [API routes to test]
- Edge cases: [list]

## Coverage
- Lines: X%
- Functions: X%
- Branches: X%

## Notes
- [Mocking complexity]
- [Flaky test warnings]
```
